class hello{
  public static void main(String args[]){
    int a=5;
    int b=16;
    System.out.println("Hello World);
    System.out.println(b-a);
    System.out.println(a+b);
  }
}
